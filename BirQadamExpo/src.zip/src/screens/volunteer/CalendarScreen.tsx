import React, { useCallback, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  useWindowDimensions,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, useNavigation } from '@react-navigation/native';

import { volunteerAPI } from '../../services/api';
import type { CalendarEvent } from '../../types';
import { appColors } from '../../theme';
import { useTranslation } from "../../locales/i18n";

const padNumber = (value: number) => value.toString().padStart(2, '0');

const formatMonthKey = (date: Date) => `${date.getFullYear()}-${padNumber(date.getMonth() + 1)}`;

const parseDateKey = (value: string) => {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(year, month - 1, day);
};

const buildDateKey = (date: Date) =>
  `${date.getFullYear()}-${padNumber(date.getMonth() + 1)}-${padNumber(date.getDate())}`;

const startOfMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth(), 1);

const addMonths = (date: Date, amount: number) => new Date(date.getFullYear(), date.getMonth() + amount, 1);

const buildCalendarDays = (monthDate: Date) => {
  const monthStart = startOfMonth(monthDate);
  const calendarStart = new Date(monthStart);
  calendarStart.setDate(monthStart.getDate() - monthStart.getDay());

  return Array.from({ length: 42 }, (_, index) => {
    const day = new Date(calendarStart);
    day.setDate(calendarStart.getDate() + index);
    return day;
  });
};

const formatMonthTitle = (date: Date) =>
  date.toLocaleDateString('ru-RU', {
    month: 'long',
    year: 'numeric',
  });

const formatSelectedDateTitle = (value: string) =>
  parseDateKey(value).toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'long',
  });

const isTodayKey = (value: string) => buildDateKey(new Date()) === value;

export const VolunteerCalendarScreen: React.FC = () => {
  const { t } = useTranslation();
  const navigation = useNavigation<any>();
  const { width } = useWindowDimensions();
  const isCompact = width < 390;

  const [displayMonth, setDisplayMonth] = useState(() => startOfMonth(new Date()));
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [selectedDateKey, setSelectedDateKey] = useState(() => buildDateKey(new Date()));
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const WEEKDAY_LABELS = useMemo(() =>
    [t('calendar.s_0'), t('calendar.s_1'), t('calendar.s_2'), t('calendar.s_3'), t('calendar.s_4'), t('calendar.s_5'), t('calendar.s_6')],
    [t]
  );

  const getEventTypeConfig = useCallback((type: string) => {
    switch (type) {
      case 'project_start':
        return {
          label: t('calendar.s_7'),
          color: '#22C55E',
          softColor: appColors.primarySurfaceStrong,
          icon: 'leaf-outline' as const,
        };
      case 'project_end':
        return {
          label: t('calendar.s_8'),
          color: '#F97316',
          softColor: appColors.warningSurface,
          icon: 'flag-outline' as const,
        };
      default:
        return {
          label: t('calendar.s_9'),
          color: appColors.danger,
          softColor: appColors.dangerSurface,
          icon: 'document-text-outline' as const,
        };
    }
  }, [t]);

  const getStatusConfig = useCallback((status?: string | null) => {
    switch (status) {
      case 'completed':
        return {
          label: t('calendar.s_10'),
          color: '#15803D',
          backgroundColor: appColors.primarySurfaceStrong,
        };
      case 'approved':
        return {
          label: t('calendar.s_11'),
          color: '#047857',
          backgroundColor: appColors.primarySurfaceStrong,
        };
      case 'under_review':
        return {
          label: t('calendar.s_12'),
          color: '#047857',
          backgroundColor: appColors.primarySurfaceStrong,
        };
      case 'revision':
        return {
          label: t('calendar.s_13'),
          color: appColors.warning,
          backgroundColor: appColors.warningSurface,
        };
      case 'rejected':
        return {
          label: t('calendar.s_14'),
          color: '#B91C1C',
          backgroundColor: appColors.dangerSurface,
        };
      case 'in_progress':
        return {
          label: t('calendar.s_15'),
          color: appColors.primary,
          backgroundColor: appColors.surfaceMuted,
        };
      case 'open':
        return {
          label: t('calendar.s_16'),
          color: '#0F766E',
          backgroundColor: appColors.primarySurface,
        };
      case 'archived':
        return {
          label: t('calendar.s_17'),
          color: appColors.textMuted,
          backgroundColor: appColors.surfaceMuted,
        };
      default:
        return status
          ? {
              label: status,
              color: appColors.textMuted,
              backgroundColor: appColors.surfaceMuted,
            }
          : null;
    }
  }, [t]);

  const formatEventTime = useCallback((event: CalendarEvent) => {
    if (event.is_all_day) {
      return t('calendar.s_18');
    }

    const start = event.start_time?.slice(0, 5);
    const end = event.end_time?.slice(0, 5);

    if (start && end) {
      return `${start} - ${end}`;
    }

    if (start) {
      return start;
    }

    return t('calendar.s_19');
  }, [t]);

  const getEventLocation = useCallback((event: CalendarEvent) =>
    event.location || event.project_address || event.project_city || t('calendar.s_20'),
  [t]);

  const selectInitialDate = useCallback((events: CalendarEvent[], monthDate: Date, previous?: string) => {
    const monthKey = formatMonthKey(monthDate);
    if (previous?.startsWith(monthKey)) {
      return previous;
    }

    const todayKey = buildDateKey(new Date());
    if (todayKey.startsWith(monthKey)) {
      return todayKey;
    }

    if (events.length > 0) {
      return events[0].date;
    }

    return buildDateKey(startOfMonth(monthDate));
  }, []);

  const monthKey = useMemo(() => formatMonthKey(displayMonth), [displayMonth]);

  const loadCalendarEvents = useCallback(
    async (showRefresh = false) => {
      if (showRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      try {
        const response = await volunteerAPI.getCalendarEvents(monthKey);
        const nextEvents = Array.isArray(response.data?.events)
          ? response.data.events.filter(
              (event) =>
                !['meeting', 'reminder'].includes(event.type) &&
                (event.source_type !== 'task' || event.status === 'open')
            )
          : [];

        setEvents(nextEvents);
        setSelectedDateKey((previous) => selectInitialDate(nextEvents, displayMonth, previous));
      } catch (error) {
        if (__DEV__) {
          console.error(t('calendar.s_21'), error);
        }
        setEvents([]);
        setSelectedDateKey(buildDateKey(startOfMonth(displayMonth)));
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [displayMonth, monthKey, selectInitialDate, t]
  );

  useFocusEffect(
    useCallback(() => {
      loadCalendarEvents();
    }, [loadCalendarEvents])
  );

  const eventsByDate = useMemo(() => {
    return events.reduce<Record<string, CalendarEvent[]>>((accumulator, event) => {
      if (!accumulator[event.date]) {
        accumulator[event.date] = [];
      }
      accumulator[event.date].push(event);
      return accumulator;
    }, {});
  }, [events]);

  const monthDays = useMemo(() => buildCalendarDays(displayMonth), [displayMonth]);
  const selectedEvents = eventsByDate[selectedDateKey] ?? [];

  const legendItems = useMemo(
    () => ['project_start', 'project_end', 'task_deadline'].map(getEventTypeConfig),
    [getEventTypeConfig]
  );

  if (loading) {
    return (
      <SafeAreaView style={styles.loadingScreen}>
        <ActivityIndicator size="large" color={appColors.primary} />
        <Text style={styles.loadingText}>{t('calendar.s_22')}</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        style={styles.screen}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => loadCalendarEvents(true)} tintColor="#10B981" />}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.headerRow}>
          <View>
            <Text style={styles.headerCaption}>{t('calendar.s_23')}</Text>
            <Text style={styles.headerTitle}>{t('calendar.s_24')}</Text>
          </View>
          <TouchableOpacity style={styles.headerAction} onPress={() => loadCalendarEvents(true)} activeOpacity={0.85}>
            <Ionicons name="refresh-outline" size={20} color="#0A0A0A" />
          </TouchableOpacity>
        </View>

        <View style={styles.calendarCard}>
          <View style={styles.monthRow}>
            <TouchableOpacity style={styles.monthButton} onPress={() => setDisplayMonth((current) => addMonths(current, -1))}>
              <Ionicons name="chevron-back" size={20} color="#0A0A0A" />
            </TouchableOpacity>

            <Text style={[styles.monthTitle, isCompact && styles.monthTitleCompact]}>
              {formatMonthTitle(displayMonth)}
            </Text>

            <TouchableOpacity style={styles.monthButton} onPress={() => setDisplayMonth((current) => addMonths(current, 1))}>
              <Ionicons name="chevron-forward" size={20} color="#0A0A0A" />
            </TouchableOpacity>
          </View>

          <View style={styles.weekdaysRow}>
            {WEEKDAY_LABELS.map((label) => (
              <Text key={label} style={styles.weekdayLabel}>
                {label}
              </Text>
            ))}
          </View>

          <View style={styles.daysGrid}>
            {monthDays.map((day) => {
              const key = buildDateKey(day);
              const dayEvents = eventsByDate[key] ?? [];
              const dayDots = Array.from(new Set(dayEvents.map((event) => getEventTypeConfig(event.type).color))).slice(0, 4);
              const isCurrentMonth = day.getMonth() === displayMonth.getMonth();
              const isSelected = key === selectedDateKey;

              return (
                <TouchableOpacity
                  key={key}
                  style={[
                    styles.dayCell,
                    isSelected && styles.dayCellSelected,
                    !isCurrentMonth && styles.dayCellMuted,
                  ]}
                  onPress={() => setSelectedDateKey(key)}
                  activeOpacity={0.85}
                >
                  <Text
                    style={[
                      styles.dayNumber,
                      !isCurrentMonth && styles.dayNumberMuted,
                      isSelected && styles.dayNumberSelected,
                      isTodayKey(key) && !isSelected && styles.dayNumberToday,
                    ]}
                  >
                    {day.getDate()}
                  </Text>

                  <View style={styles.dayDotsRow}>
                    {dayDots.map((color) => (
                      <View key={`${key}-${color}`} style={[styles.dayDot, { backgroundColor: color }]} />
                    ))}
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>

          <View style={styles.legendRow}>
            {legendItems.map((item) => (
              <View key={item.label} style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: item.color }]} />
                <Text style={styles.legendText}>{item.label}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>{t('calendar.s_25')}{formatSelectedDateTitle(selectedDateKey)}</Text>
          <Text style={styles.sectionCount}>{selectedEvents.length}</Text>
        </View>

        {selectedEvents.length ? (
          selectedEvents.map((event) => {
            const typeConfig = getEventTypeConfig(event.type);
            const statusConfig = getStatusConfig(event.status);

            return (
              <TouchableOpacity
                key={event.id}
                style={styles.eventCard}
                activeOpacity={0.92}
                onPress={() => navigation.navigate('CalendarEventDetail', { event })}
              >
                <View style={[styles.eventIconWrap, { backgroundColor: typeConfig.softColor }]}>
                  <Ionicons name={typeConfig.icon} size={22} color={typeConfig.color} />
                </View>

                <View style={styles.eventBody}>
                  <View style={styles.eventHeaderRow}>
                    <Text style={styles.eventTitle} numberOfLines={2}>
                      {event.title}
                    </Text>
                    {statusConfig ? (
                      <View style={[styles.statusBadge, { backgroundColor: statusConfig.backgroundColor }]}>
                        <Text style={[styles.statusBadgeText, { color: statusConfig.color }]}>{statusConfig.label}</Text>
                      </View>
                    ) : null}
                  </View>

                  <Text style={styles.eventSubtitle} numberOfLines={1}>
                    {event.subtitle || typeConfig.label}
                  </Text>

                  <View style={styles.eventMetaRow}>
                    <Ionicons name="time-outline" size={14} color={appColors.textMuted} />
                    <Text style={styles.eventMetaText}>{formatEventTime(event)}</Text>
                  </View>

                  <View style={styles.eventMetaRow}>
                    <Ionicons name="location-outline" size={14} color={appColors.textMuted} />
                    <Text style={styles.eventMetaText} numberOfLines={1}>
                      {getEventLocation(event)}
                    </Text>
                  </View>
                </View>
              </TouchableOpacity>
            );
          })
        ) : (
          <View style={styles.emptyCard}>
            <Ionicons name="calendar-clear-outline" size={28} color={appColors.textMuted} />
            <Text style={styles.emptyTitle}>{t('calendar.s_26')}</Text>
            <Text style={styles.emptyText}>{t('calendar.s_27')}</Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};
